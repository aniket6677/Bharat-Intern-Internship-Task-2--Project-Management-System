<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fggs_rs";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$id = $_GET['id'];

$prog = $conn->query("SELECT * FROM project_progress natural join project_division where project_id = '$id' ");
    $prog2 = $conn->query("SELECT SUM(progress) as total FROM project_progress natural join project_division where project_id = '$id' ");
    $progress2 = $prog2 ->fetch_assoc();
$total = $progress2['total'] / $prog->num_rows ;
$tots= number_format($total,0);
              $colors='rgba(0, 241, 5, 0.39)';  
            
        echo '{"progress":'.'"'. $tots.'"'.','.'"name":"Total"'.','.'"color":"'. $colors.'"}';
 	 
	



$conn->close();

?>
